package temp;

public class Test 
{

	 public static void abc()
	 {
		 System.out.println(" In a abc method !!!\n");
	 }

	 public void def()
	 {
		 System.out.println(" In a def method !!!\n");
	 }

}
