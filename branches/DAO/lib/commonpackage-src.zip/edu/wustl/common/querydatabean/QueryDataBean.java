package edu.wustl.common.querydatabean;

/**
 * @author kalpana_thakur
 *This will implemented by QueryResultObjectDataBean.
 *TODO
 */
public interface QueryDataBean
{

}
