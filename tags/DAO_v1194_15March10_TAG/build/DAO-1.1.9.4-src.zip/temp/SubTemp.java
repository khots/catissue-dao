package temp;

public class SubTemp extends Test
{
	public static void abc()
	 {
		 System.out.println(" In a SubTemp method !!!\n");
	 }
	
	public static void main(String[] args)
	{
		Test subTemp = new SubTemp();
		subTemp.abc();
		subTemp.def();
	}
	
	 public void def()
	 {
		 System.out.println(" In a def method !!!\n");
	 }

}
