package edu.wustl.dao;

/**
 * Marker Interface ,this is to support some customize implementation.
 * @author ravi_kumar
 *
 */
public interface IDAOExtention
{

}
