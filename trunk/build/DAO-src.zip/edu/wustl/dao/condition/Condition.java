package edu.wustl.dao.condition;

/**
 * @author kalpana_thakur
 * TODO
 */
public interface Condition
{
	/**
	 * @param columnName :
	 * @param condition :
	 * @param values :
	 * @return :
	 *//*
	String addCondition(String columnName , String condition ,String values);
	*//**
	 * @param columnName :
	 * @param condition :
	 * @param object :
	 * @return :
	 *//*
	String addCondition(String columnName , String condition , Object[] object);
*/


	/**
	 * Returns the string value.
	 * @return String:
	 */
	String toString();
}
